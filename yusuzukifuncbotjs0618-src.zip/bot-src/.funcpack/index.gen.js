module.exports = {
    "messages": require("../messages/index.js")
}